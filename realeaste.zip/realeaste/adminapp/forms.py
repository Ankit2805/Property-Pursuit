from django import forms
from django.contrib.auth.forms import UserCreationForm
from . import models

class RegisterForm(UserCreationForm):
    class Meta:
        model = models.User
        fields = ('username','password1','password2','email','is_admin','is_dealer','is_client')
