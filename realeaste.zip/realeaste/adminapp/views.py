from django.shortcuts import render,HttpResponse
from . import forms
# Create your views here.

def register(request):
    if request.method == 'POST':
        form = forms.RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("Dtat Success")
        else:
            return HttpResponse("Eror")
    form = forms.RegisterForm()
    return render(request, 'dealer/register.html',{'form':form})

