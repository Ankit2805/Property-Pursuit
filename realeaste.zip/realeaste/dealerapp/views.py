from django.contrib import auth
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render, redirect
# Create your views here.
def login(request):
        return render(request,'dealer/login.html')
def register(request):
        return render(request,'dealer/register.html')


def dashboard(request):
    return render(request,'dealer/index.html')

def property_add_details(request):
    return render(request,'dealer/property-add_details.html')

def property_manage_details(request):
    return render(request,'dealer/property-manage.html')

def property_add_amenities(request):
    return render(request,'dealer/property-add_amenities.html')

def profile(request):
    return render(request,'dealer/users-profile.html')