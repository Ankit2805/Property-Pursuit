from django.apps import AppConfig


class DealerappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dealerapp'
