from django.urls import path
from  . import views

urlpatterns = [
    path('',views.dashboard,name='dashboard'),
    path('add/',views.property_add_details,name='add_details'),
    path('manage/',views.property_manage_details,name='manage_details'),
    path('amenities/',views.property_add_amenities,name='amenities_details'),
    path('login/',views.login,name='login'),
    path('register/',views.register,name='register'),
    path('profile/',views.profile,name='profile'),
]
